# DilVerse💓 — Android starter app

A cute anime-inspired couples companion with:
- Mood check-in and optional note
- Daily couple missions with completion tracking
- Memory stars
- Future mail (date-gated in the app)
- Tap-to-decorate dream room
- Shared promises and partner display name

## Run on Android
1. Install Node.js on a computer.
2. Extract this folder and run `npm install`.
3. Run `npx expo start`.
4. Install **Expo Go** on your Android phone and scan the QR code.

Data is stored locally on the device using AsyncStorage. This starter does not yet sync between two phones, send push notifications, or provide account/login features.

## Build an installable APK
1. Install EAS CLI: `npm install -g eas-cli`
2. Sign in: `eas login`
3. From this folder run: `eas build -p android --profile preview`
4. Follow the prompts. EAS will provide an APK build link when complete.

For a real shared couple account, add a secure backend (authentication, database, access rules) before storing private couple content online.
