import React, { useEffect, useMemo, useState } from "react";
import { SafeAreaView, ScrollView, View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const PINK = "#F7A8C8", PURPLE = "#9B82D8", INK = "#382B50", BG = "#FFF4FA";
const initial = { partner:"My Person", mood:"🥰", moodNote:"", memories:[], letters:[], promises:[], room:["🛏️","🪴","🧸"], completed:[] };
const missions = [
  {id:"m1", title:"Send a tiny appreciation", detail:"Tell your person one little thing you appreciate about them.", icon:"💌"},
  {id:"m2", title:"Memory lane", detail:"Share a favourite moment you both remember.", icon:"🌷"},
  {id:"m3", title:"Two truths", detail:"Ask each other two fun questions and guess the answers.", icon:"🎀"},
  {id:"m4", title:"Future date", detail:"Plan one simple thing you'd love to do together.", icon:"🌙"}
];
function Btn({children,onPress,secondary=false}) { return <TouchableOpacity onPress={onPress} style={[s.btn,secondary&&s.btn2]}><Text style={[s.btnText,secondary&&s.btnText2]}>{children}</Text></TouchableOpacity> }
function Card({children}) { return <View style={s.card}>{children}</View> }
function Heading({children}) { return <Text style={s.heading}>{children}</Text> }

export default function App(){
 const [data,setData]=useState(initial), [tab,setTab]=useState("Home"), [memory,setMemory]=useState(""), [letter,setLetter]=useState(""), [date,setDate]=useState(""), [promise,setPromise]=useState("");
 useEffect(()=>{ AsyncStorage.getItem("dilverse-data").then(v=>{if(v) setData({...initial,...JSON.parse(v)});}).catch(()=>{}); },[]);
 useEffect(()=>{ AsyncStorage.setItem("dilverse-data",JSON.stringify(data)).catch(()=>{}); },[data]);
 const update=(k,v)=>setData(d=>({...d,[k]:v}));
 const delivered = useMemo(()=>data.letters.filter(x=>!x.date || new Date(x.date+"T23:59:59")<=new Date()),[data.letters]);
 const addMemory=()=>{if(!memory.trim())return; update("memories",[{id:Date.now().toString(),text:memory.trim(),date:new Date().toLocaleDateString()},...data.memories]);setMemory("");};
 const addLetter=()=>{if(!letter.trim())return; if(date && isNaN(Date.parse(date))) {Alert.alert("Date format","Use YYYY-MM-DD.");return;} update("letters",[{id:Date.now().toString(),text:letter.trim(),date,created:new Date().toLocaleDateString()},...data.letters]);setLetter("");setDate("");Alert.alert("Saved 💗","Your future mail is safely saved on this device.");};
 const addPromise=()=>{if(!promise.trim())return;update("promises",[promise.trim(),...data.promises]);setPromise("");};
 const toggleMission=id=>update("completed",data.completed.includes(id)?data.completed.filter(x=>x!==id):[...data.completed,id]);
 const tabs=[["Home","🏠"],["Mood","🫧"],["Missions","🎮"],["Memories","⭐"],["Our Space","🏡"]];
 return <SafeAreaView style={s.safe}><StatusBar barStyle="dark-content" backgroundColor={BG}/><View style={s.top}><View><Text style={s.brand}>DilVerse💓</Text><Text style={s.sub}>two hearts, one little universe</Text></View><Text style={s.topHeart}>♡</Text></View>
 <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
 {tab==="Home" && <>
  <View style={s.hero}><Text style={s.eyebrow}>YOUR LITTLE UNIVERSE</Text><Text style={s.heroTitle}>Hi, {data.partner} ✨</Text><Text style={s.heroText}>A soft place for your favourite memories, tiny promises and everyday love.</Text><Text style={s.bigHeart}>💗</Text></View>
  <Card><Heading>Today's little check-in</Heading><Text style={s.body}>How are you feeling today?</Text><Text style={s.moodBig}>{data.mood}</Text><Text style={s.muted}>{data.moodNote||"Your mood is your message. No pressure to explain."}</Text><Btn onPress={()=>setTab("Mood")}>Update my mood</Btn></Card>
  <Card><Heading>Our universe at a glance 🌌</Heading><View style={s.stats}><View><Text style={s.statNum}>{data.memories.length}</Text><Text style={s.muted}>Memories</Text></View><View><Text style={s.statNum}>{data.promises.length}</Text><Text style={s.muted}>Promises</Text></View><View><Text style={s.statNum}>{data.completed.length}</Text><Text style={s.muted}>Missions</Text></View></View></Card>
  <Card><Heading>Little reminder 🌷</Heading><Text style={s.body}>Love is also in the small things: listening, kindness, honesty and giving each other room to grow.</Text></Card>
 </>}
 {tab==="Mood" && <>
  <Heading>Mood without words 🫧</Heading><Text style={s.body}>Pick the emoji that feels closest today. You can add a note if you want.</Text>
  <View style={s.emojiGrid}>{["🥰","😊","😴","🥺","😔","😤","🤩","🫶"].map(e=><TouchableOpacity key={e} onPress={()=>update("mood",e)} style={[s.emojiCell,data.mood===e&&s.selected]}><Text style={{fontSize:34}}>{e}</Text></TouchableOpacity>)}</View>
  <Card><Text style={s.label}>A little note (optional)</Text><TextInput value={data.moodNote} onChangeText={v=>update("moodNote",v)} placeholder="Today I'm feeling..." placeholderTextColor="#B49BAE" style={s.input}/><Btn onPress={()=>Alert.alert("Mood saved 💗","Your check-in is saved on this device.")}>Save mood</Btn></Card>
  <Text style={s.muted}>A mood is an invitation to understand, not a demand for an instant reply.</Text>
 </>}
 {tab==="Missions" && <>
  <Heading>Couple missions 🎮</Heading><Text style={s.body}>Tiny prompts to help you connect. Do them together or send one to your person.</Text>
  {missions.map(m=><Card key={m.id}><View style={s.row}><Text style={s.missionIcon}>{m.icon}</Text><View style={{flex:1}}><Text style={s.cardTitle}>{m.title}</Text><Text style={s.body}>{m.detail}</Text></View></View><Btn secondary={data.completed.includes(m.id)} onPress={()=>toggleMission(m.id)}>{data.completed.includes(m.id)?"Completed ✓":"Mark as done"}</Btn></Card>)}
 </>}
 {tab==="Memories" && <>
  <Heading>Our memory stars ⭐</Heading><Text style={s.body}>Save little moments you want to remember.</Text>
  <Card><TextInput value={memory} onChangeText={setMemory} placeholder="A moment I want to keep..." placeholderTextColor="#B49BAE" style={s.input}/><Btn onPress={addMemory}>Add memory ✨</Btn></Card>
  {data.memories.length===0?<Text style={s.empty}>Your memory sky is waiting for its first star. 🌟</Text>:data.memories.map(m=><Card key={m.id}><Text style={s.memoryText}>✦ {m.text}</Text><Text style={s.muted}>{m.date}</Text></Card>)}
  <Heading>Future mail 💌</Heading><Card><Text style={s.body}>Write a note for a future day. Use YYYY-MM-DD, or leave the date blank to keep it in your mailbox.</Text><TextInput value={letter} onChangeText={setLetter} multiline placeholder="Dear future us..." placeholderTextColor="#B49BAE" style={[s.input,{height:90,textAlignVertical:"top"}]}/><TextInput value={date} onChangeText={setDate} placeholder="Delivery date (YYYY-MM-DD)" placeholderTextColor="#B49BAE" style={s.input}/><Btn onPress={addLetter}>Seal this letter 💗</Btn></Card>
  <Text style={s.sectionLabel}>MAILBOX · {delivered.length} available</Text>
  {delivered.map(l=><Card key={l.id}><Text style={s.memoryText}>💌 {l.text}</Text><Text style={s.muted}>Saved {l.created}</Text></Card>)}
  {data.letters.filter(x=>x.date && new Date(x.date+"T23:59:59")>new Date()).length>0&&<Text style={s.muted}>Some letters are still sealed until their delivery date.</Text>}
 </>}
 {tab==="Our Space" && <>
  <Heading>Our dream room 🏡</Heading><Text style={s.body}>A tiny shared space. Tap an item to cycle through cozy decorations.</Text>
  <View style={s.room}><Text style={s.roomTitle}>♡ OUR LITTLE HOME ♡</Text><View style={s.roomItems}>{data.room.map((it,i)=><TouchableOpacity key={i} onPress={()=>update("room",data.room.map((v,j)=>j===i?["🛏️","🛋️","🪴","🧸","🕯️","🌸","⭐"][([...["🛏️","🛋️","🪴","🧸","🕯️","🌸","⭐"].indexOf(v)]+1)%7]:v))} style={s.roomItem}><Text style={{fontSize:42}}>{it}</Text><Text style={s.muted}>tap to change</Text></TouchableOpacity>)}</View><Text style={s.roomFooter}>made of little moments & kindness</Text></View>
  <Card><Text style={s.label}>Partner's display name</Text><TextInput value={data.partner} onChangeText={v=>update("partner",v)} style={s.input} placeholder="My Person"/><Btn onPress={()=>Alert.alert("Saved","Your display name has been updated.")}>Save name</Btn></Card>
  <Card><Heading>Our tiny promises 🤝</Heading><TextInput value={promise} onChangeText={setPromise} placeholder="One promise we want to keep..." placeholderTextColor="#B49BAE" style={s.input}/><Btn onPress={addPromise}>Add promise</Btn>{data.promises.map((p,i)=><Text key={i} style={s.promise}>♡ {p}</Text>)}</Card>
 </>}
 </ScrollView>
 <View style={s.nav}>{tabs.map(([t,ic])=><TouchableOpacity key={t} onPress={()=>setTab(t)} style={s.navItem}><Text style={{fontSize:20}}>{ic}</Text><Text style={[s.navText,tab===t&&s.navActive]}>{t}</Text></TouchableOpacity>)}</View>
 </SafeAreaView>
}
const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:BG},top:{paddingHorizontal:20,paddingTop:10,paddingBottom:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},brand:{fontSize:26,fontWeight:"900",color:"#A94F83"},sub:{fontSize:11,color:"#98788E",letterSpacing:1},topHeart:{fontSize:36,color:PURPLE},content:{padding:16,paddingBottom:30,gap:14},hero:{backgroundColor:"#FCE0EF",borderRadius:28,padding:22,minHeight:190,overflow:"hidden"},eyebrow:{fontSize:10,letterSpacing:2,color:"#A45D86",fontWeight:"800"},heroTitle:{fontSize:30,fontWeight:"900",color:INK,marginTop:10},heroText:{fontSize:14,color:"#74556E",lineHeight:21,maxWidth:"82%",marginTop:6},bigHeart:{position:"absolute",right:12,bottom:12,fontSize:76},card:{backgroundColor:"#FFFFFF",borderRadius:22,padding:17,borderWidth:1,borderColor:"#F5DCE9",gap:10},heading:{fontSize:20,fontWeight:"800",color:INK,marginBottom:4},body:{fontSize:14,color:"#755F73",lineHeight:21},muted:{fontSize:12,color:"#A28A9B",lineHeight:18},moodBig:{fontSize:42},btn:{backgroundColor:PURPLE,paddingVertical:12,paddingHorizontal:16,borderRadius:15,alignItems:"center",marginTop:5},btn2:{backgroundColor:"#FCE8F2",borderWidth:1,borderColor:"#F1C9DC"},btnText:{color:"#FFFFFF",fontWeight:"800",fontSize:14},btnText2:{color:"#995A82"},stats:{flexDirection:"row",justifyContent:"space-around",paddingVertical:8},statNum:{fontSize:25,fontWeight:"900",color:"#A95C8B",textAlign:"center"},emojiGrid:{flexDirection:"row",flexWrap:"wrap",gap:10,justifyContent:"center"},emojiCell:{width:"22%",aspectRatio:1,backgroundColor:"#FFFFFF",borderRadius:18,alignItems:"center",justifyContent:"center",borderWidth:1,borderColor:"#F3DCE8"},selected:{borderColor:PURPLE,borderWidth:3,backgroundColor:"#F1EAFE"},label:{fontWeight:"800",color:INK},input:{backgroundColor:"#FFF7FB",borderWidth:1,borderColor:"#F0D7E5",borderRadius:13,padding:13,color:INK,fontSize:14},row:{flexDirection:"row",gap:12,alignItems:"center"},missionIcon:{fontSize:32},cardTitle:{fontSize:16,fontWeight:"800",color:INK},empty:{textAlign:"center",color:"#A28A9B",padding:20},memoryText:{fontSize:16,color:INK,lineHeight:23},sectionLabel:{fontSize:11,fontWeight:"900",letterSpacing:1,color:"#A45D86",marginTop:8},room:{backgroundColor:"#F0E8FF",borderRadius:26,padding:20,minHeight:230,justifyContent:"space-between",borderWidth:1,borderColor:"#DCCCF8"},roomTitle:{textAlign:"center",fontWeight:"900",color:"#795FA6",letterSpacing:2},roomItems:{flexDirection:"row",justifyContent:"space-around",marginVertical:30},roomItem:{alignItems:"center",backgroundColor:"#FFFFFFAA",borderRadius:18,padding:10},roomFooter:{textAlign:"center",color:"#8D76B2",fontStyle:"italic"},promise:{fontSize:14,color:"#76516C",paddingVertical:5},nav:{flexDirection:"row",backgroundColor:"#FFFFFF",borderTopWidth:1,borderColor:"#F0DDE8",paddingTop:8,paddingBottom:7,justifyContent:"space-around"},navItem:{alignItems:"center",minWidth:55},navText:{fontSize:10,color:"#A28A9B",marginTop:2},navActive:{color:"#A94F83",fontWeight:"900"}
});